//
//  contacto2ViewController.swift
//  CibertecApp07
//
//  Created by DAMII on 17/10/23.
//

import UIKit


struct Contacto {
    var nombre : String
    var telefono : Int
}


class contacto2ViewController: UIViewController, UITableViewDataSource {

    

    //invocacion
    
    @IBOutlet weak var contactosTableView: UITableView!
    
    var contactosList: [Contacto] = []
    
    

    @IBOutlet weak var alertaBtn: UIBarButtonItem!
    //no es necesario invocar botones, so con acciones
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        contactosTableView.dataSource = self
        contactosList.append(Contacto(nombre: "Carl Johnson", telefono: 999876123))
        contactosList.append(Contacto(nombre: "Vitoria Petrova", telefono: 999876003))
        contactosList.append(Contacto(nombre: "Walter Petrov", telefono: 900387612))
        contactosList.append(Contacto(nombre: "Paul Petrov", telefono: 987123456))

        // Do any additional setup after loading the view.
    }
    

    @IBAction func abrirAlertaRegistro(_ sender: Any) {
    }
    
    //Numero de filas
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactosList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "contactoCell", for: indexPath) as! contactoTableViewCell
                     let contacto = contactosList[indexPath.row]
                     cell.nombreApellidoLabel.text = contacto.nombre
                        cell.telefonoLabel.text = String(contacto.telefono)
        
                return cell
    }

}
