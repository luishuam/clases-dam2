//
//  contactoViewController.swift
//  Sesion05_repaso
//
//  Created by DAMII on 19/09/23.
//

import UIKit

class contactoViewController: UIViewController {

    
    //Sin cargar
    
    
    @IBOutlet weak var nombres: UITextField!
    
    
    @IBOutlet weak var apellidos: UITextField!
    
    
    @IBOutlet weak var telefono: UITextField!
    
    
    @IBOutlet weak var btnRegistrar: UIButton!
    
    
    @IBOutlet weak var estadiSegment: UISegmentedControl!
    
    
    @IBOutlet weak var estadoSwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
    
    }
    
    
    
    @IBAction func registrarContacto(_ sender: UIButton) {
        
        let nombre = nombres.text
        let apellido = apellidos.text
        let telefono = telefono.text
        
        if let name = nombre, let lastname = apellido, let phone = telefono {
            print(name)
            print(lastname)
            print(phone)
            
        }
        else {
            // Alert de campos incompletos
        }

    }
    
    
    @IBAction func opcionSeleccionar(_ sender: Any) {
        
        let estCivil = estadiSegment.selectedSegmentIndex
        print(estCivil)

    }
    
    
    @IBAction func accionSeleccionar(_ sender: Any) {
        
        let estado = estadoSwitch.isOn
        print(estado)

    }
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
